Coverage-Guided Fuzzer Output Directory
===================================

Directory Structure:
- queue/: Directory containing all test cases
- crashes/: Directory containing inputs that caused crashes
- hangs/: Directory containing inputs that caused hangs
- plots/: Coverage and performance graphs
- logs/: Detailed execution logs

Files:
- cmdline: Command line used for running the target
- fuzz_bitmap: Fuzzer bitmap data
- fuzzer_setup: Fuzzer configuration details
- fuzzer_stats: Internal fuzzer state statistics
- plot_data: Fuzzing test statistical data
- coverage_report.html: Interactive coverage report

Created: 2024-12-05T13:58:34.490755
